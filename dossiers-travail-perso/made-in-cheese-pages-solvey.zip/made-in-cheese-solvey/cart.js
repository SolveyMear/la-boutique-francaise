const slide = ["./assets/images/fromage-main.jpeg", "./assets/images/portrait2.jpeg", "./assets/images/fromage-main.jpeg"];
let numero = 0;

function changeSlide(sens) {
    console.log(sens)
    numero = numero + sens;
    if(numero < 0)
        numero = slide.length -1;
    if(numero > slide.length -1)
        numero = 0;
    document.getElementById("slide").src = slide[numero]
    setInterval("changeSlide(1)", 6000);
}

console.log(changeSlide)